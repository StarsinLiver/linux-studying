OC.L10N.register(
    "files_external",
    {
    "Step 2 failed. Exception: %s" : "ຂັ້ນຕອນທີ 2 ລົ້ມເຫລວ. ຂໍ້​ຍົກ​ເວັ້ນ: %s",
    "Error verifying OAuth2 Code for " : "ຂໍ້ຜິດພາດຢືນຢັນລະຫັດ OAuth2 ສໍາລັບ",
    "Personal" : "ສ່ວນບຸກຄົນ"
},
"nplurals=1; plural=0;");
