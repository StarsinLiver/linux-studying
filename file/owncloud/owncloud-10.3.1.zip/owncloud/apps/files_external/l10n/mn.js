OC.L10N.register(
    "files_external",
    {
    "Username" : "Хэрэглэгчийн нэр",
    "Password" : "Нууц үг",
    "Save" : "Хадгалах",
    "Share" : "Түгээх",
    "Delete" : "Устгах"
},
"nplurals=2; plural=(n != 1);");
