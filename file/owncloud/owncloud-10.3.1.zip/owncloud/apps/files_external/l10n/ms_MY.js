OC.L10N.register(
    "files_external",
    {
    "Personal" : "Peribadi",
    "Username" : "Nama pengguna",
    "Password" : "Kata laluan",
    "Save" : "Simpan",
    "URL" : "URL",
    "Location" : "Lokasi",
    "ownCloud" : "ownCloud",
    "Share" : "Kongsi",
    "Name" : "Nama",
    "Delete" : "Padam"
},
"nplurals=1; plural=0;");
