<?php
$TRANSLATIONS = array(
"Documentation" => "Dokumentatioun"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
