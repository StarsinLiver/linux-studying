OC.L10N.register(
    "firstrunwizard",
    {
    "A safe home for all your data" : "Turvaline kodu kõigile sinu andmetele",
    "Get the apps to sync your files" : "Hangi rakendusi failide sünkroniseerimiseks",
    "Desktop client" : "Töölaua klient",
    "Android app" : "Androidi rakendus",
    "iOS app" : "iOS-i rakendus",
    "Connect your desktop apps to %s" : "Ühenda oma töölaua rakendus %s",
    "Connect your Calendar" : "Ühenda oma kalender",
    "Connect your Contacts" : "Ühenda oma kontaktid",
    "Documentation" : "Dokumentatsioon",
    "Access files via WebDAV" : "Ligipääs WebDAV vahendusel",
    "There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." : "Rohkem infot leiad <a target=\"_blank\" href=\"%s\">dokumentatsioonist</a> ja meie <a target=\"_blank\" href=\"http://owncloud.org\">veebilehelt</a>."
},
"nplurals=2; plural=(n != 1);");
