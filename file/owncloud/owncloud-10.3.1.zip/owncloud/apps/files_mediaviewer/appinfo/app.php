<?php
/**
 * Mediaviewer
 *
 * This file is licensed under the General Public License version 2
 * See the COPYING file.
 *
 * @author Felix Heidecke <felix@heidecke.me>
 */

use OCP\Util;

Util::addScript('files_mediaviewer', 'files_mediaviewer_init');
Util::addStyle('files_mediaviewer', 'files_mediaviewer');
