# files_mediaviewer
Viewer for pictures and videos integrated in the files app

![2018-12-12 13-08-17 2018-12-12 13_09_44](https://user-images.githubusercontent.com/12717530/49868973-43303f00-fe0f-11e8-8f7a-1a5460f51fcd.gif)

## Building

Requires
* Node.js
* NPM

Run `npm install && npm run build` to build.
